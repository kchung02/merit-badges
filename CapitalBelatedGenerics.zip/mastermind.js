//main();

function main(){
  var code=[], guess=[], feedback=[], colors=["r", "y", "g", "c", "b", "w"], turns=[], mmPrompt = null;
  code = setUpCode();
  while(feedback[3] != "b" && guess[0] != "q"){
    guess = getGuess();
    feedback = analyzeGuess();
    addTurn();
    console.log(turns.length, guess, feedback);
  }
  if(turns[turn][1][3] == "b"){
    alert("Congrats! You guessed it in "+turns.length+" turns.");
  }
  else{
    alert("Quitter!");
  }
  
  function setUpCode(){
    code = [];
    for(let peg = 0; peg <= 3; peg++){
      let color = Math.floor(Math.random()*6);
      code[peg] = colors[color];
    }
    console.log(code);
    return code;
  }
  
  function getGuess(){
    guess = [];
    let guessString = prompt(displayTurns());
    guess = guessString.split(",");
    console.log(guess);
    return guess;
  }
  
  function analyzeGuess(guessArray){
    feedbackArray = [];
    let guessedCode = [];
    let goodGuesses = [];
    for(let i=0; i<4; i++){
      if(guessArray[i]==code[i]){
        feedbackArray.push("b");
        guessedCode.push(i);
        goodGuesses.push(i);
      }
    }
    for(let g=0; g<4; g++){
      if(!goodGuesses.includes(g)){
        for(let c=0; c<4; c++){
          if(!guessedCode.includes(c)){
            if(guessArray[g]==code[c]){
            feedbackArray.push("w");
            guessedCode.push(c);
            goodGuesses.push(g);
            continue;
            }
          }
        }
      }
    return feedbackArray;
    }
  }
  
  function addTurn(){
    var turn=[];
    turn.push(guess);
    turn.push(feedback);
    turns.push(turn);
  }

  function displayTurns(){
    mmPrompt="";
    for(let turn = 0; turn < turns.length; turn++){
      mmPrompt += "guess "+(turn+1)+" : ";
      mmPrompt += turns[turn][0].join(" ") +  " || ";
      mmPrompt += turns[turn][1].join(" ") +  " \n ";
    }
    mmPrompt += "\n Please enter your guess";
    return mmPrompt;
  }
}