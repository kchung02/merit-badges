var code = [], guessArray = [], feedbackArray = [], colors = ["r", "y", "g", "c", "b", "w"], allFeedback = "", guesses = 0;

setup();

function setup() {
  var play = document.createElement("button");
  play.innerHTML = "Play Mastermind!";
  play.addEventListener("click", startGame);
  play.setAttribute("id", "play");
  document.body.append(play);
}

function startGame() {
  var konsole = document.getElementById("konsole");
  var feedback = document.createElement("div");
  konsole.setAttribute("class","konsole");
  feedback.setAttribute("id", "feedback");
  konsole.appendChild(feedback);
  code = setUpCode();
  feedback.innerHTML = "Colors are: r,y,b,w,g,c.";
  play.innerHTML = "New Game";
  play.removeEventListener("click", startGame);
  play.addEventListener("click", webMain);
}

function webMain() {
  var guess = document.createElement("textarea");
  guess.setAttribute("id", "guess");
  konsole = document.getElementById("konsole");
  konsole.appendChild(guess);
  feedback.innerHTML = "Enter a guess in the yellow box as 4 colors with commas between, no spaces:";
  play.innerHTML = "Submit Guess";
  play.removeEventListener("click", webMain);
  play.addEventListener("click", newGetGuess);
}

function newGetGuess() {
  var guessString = document.getElementById("guess").value;
  guess.value = "";
  guessArray = guessString.split(",");
  guesses++;
  feedbackArray = analyzeGuess(guessArray);
  if (feedbackArray[3] == "b"){
    allFeedback += "<p>You won in "+guesses+" guesses!<\p>";
  }
  else {
    allFeedback += "<p>Guess "+guesses+": "+guessArray+" || "+feedbackArray+"<\p>";
    var konsole = document.getElementById("konsole");
    konsole.setAttribute("backgroundColor" , "lime");
  }
  feedback.innerHTML = allFeedback;
}


/*From Mastermind*/

function setUpCode(){
    code = [];
    for(let peg = 0; peg <= 3; peg++){
      let color = Math.floor(Math.random()*6);
      code[peg] = colors[color];
    }
    console.log(code);
    return code;
}

function analyzeGuess(guessArray){
  feedbackArray = [];
  let guessedCode = [];
  let goodGuesses = [];
  for(let i=0; i<4; i++){
    if(guessArray[i]==code[i]){
      feedbackArray.push("b");
      guessedCode.push(i);
      goodGuesses.push(i);
    }
  }
  for(let g=0; g<4; g++){
    if(!goodGuesses.includes(g)){
      for(let c=0; c<4; c++){
        if(!guessedCode.includes(c)){
          if(guessArray[g]==code[c]){
          feedbackArray.push("w");
          guessedCode.push(c);
          goodGuesses.push(g);
          break;
          }
        }
      }
    }
  return feedbackArray;
  }
}